<?php
$servername = "localhost"; 
$username = "root";        
$password = "";          
$dbname = "companion"; 

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);
$data = mysqli_connect($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check connection
if (!$data) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
