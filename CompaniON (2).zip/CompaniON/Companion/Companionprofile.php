<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON Profile</title>
    <link rel="stylesheet" href="companionprofile.css"> <!-- Link to your external CSS -->
</head>
<body>
<div class="container">
    <header>
        <div class="logo">
            <h1>CompaniON</h1>  
        </div>
        <div class="nav">
            <input type="text" placeholder="What are you looking for?">
            <ul>

                <li><a href="companionprofile.php">Profile</a></li>                
                <li><a href="companionnotif.php">Notifications</a></li>
                <li><a href="verify.php">Verify</a></li>
                <li><a href="history.php">History</a></li>
            </ul>
        </div>
    </header>
    <!-- Profile Section -->
    <div class="profile-section">
        <div class="grid-container">
            <!-- Profile Header -->
            <div class="profile-header">
                <h1>Welcome, Username <span class="verified">✔</span></h1>
                <p>Short description about yourself. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec porttitor ex vel nulla maximus.</p>
                <a href="editcompanionprofile.php">
                    <button class="edit-profile-btn">Edit Profile</button>
                </a>
                <p class="status">Status: <span class="verified">Verified</span></p>
            </div>

            <!-- Left side: Notifications -->
            <div class="notifications-section">
                <h3>Top Notifications</h3>
                <div class="notification-item">
                    <img src="avatar1.png" alt="User Image">
                    <p>Kylla Mae P. Paragas</p>
                    <button class="view-btn">View</button>
                    <button class="archive-btn">Archive</button>
                    <button class="delete-btn">Delete</button>          
                    </div>
                <div class="notification-item">
                    <img src="avatar2.png" alt="User Image">
                    <p>Glycel Yvon R. Virtucio</p>
                    <button class="view-btn">View</button>
                    <button class="archive-btn">Archive</button>
                    <button class="delete-btn">Delete</button>           
                </div>
                <div class="notification-item">
                    <img src="avatar3.png" alt="User Image">
                    <p>Earl John M. Guno</p>
                    <button class="view-btn">View</button>
                    <button class="archive-btn">Archive</button>
                    <button class="delete-btn">Delete</button>


                </div>
                <button class="view-more-btn">View More...</button>
            </div>

            <!-- Right side: Availability, Ongoing Booking, and Events -->
            <div class="side-section">
                <div class="availability">
                    <h3>Your Availability</h3>
                    <p>Update your availability status here.</p>
                    <button class="update-btn">Update</button>
                </div>

                <div class="ongoing-bookings">
                    <h3>Ongoing Booking</h3>
                    <p>Details about your ongoing bookings.</p>
                    <button class="view-btn">View</button>
                </div>

                <div class="events">
                    <h3>Events</h3>
                    <div class="event-item">
                        <p>Social Gathering</p>
                        <p>Details about the event</p>
                    </div>
                    <div class="event-item">
                        <p>Social Gathering</p>
                        <p>Details about the event</p>
                    </div>
                    <button class="view-more-btn">View More...</button>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
