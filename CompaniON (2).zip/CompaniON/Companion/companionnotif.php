<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON Notifications</title>
    <link rel="stylesheet" href="companionnotif.css"> <!-- Link to your external CSS -->
</head>
<body>
<div class="container">
<header>
        <div class="logo">
            <h1>CompaniON</h1>  
        </div>
        <div class="nav">
            <input type="text" placeholder="What are you looking for?">
            <ul>

                <li><a href="companionprofile.php">Profile</a></li>                
                <li><a href="companionnotif.php">Notifications</a></li>
                <li><a href="verify.php">Verify</a></li>
                <li><a href="history.php">History</a></li>
            </ul>
        </div>
    </header>
    <!-- Main Section -->
    <div class="main">
        <div class="menu">
            <h3>Menu</h3>
            <button class="menu-item active">Notifications</button>
            <button class="menu-item">Archives</button>
            <button class="menu-item">Deleted</button>
            <div class="recommended">
                <h3>Recommended Places</h3>
                <div class="place">
                    <p>Short description about event. Lorem ipsum dolor sit amet.</p>
                    <button class="view-btn">View Details</button>
                </div>
                <div class="place">
                    <p>Short description about event. Lorem ipsum dolor sit amet.</p>
                    <button class="view-btn">View Details</button>
                </div>
            </div>
        </div>

        <!-- Notifications Section -->
        <div class="notifications-section">
            <h3>Notifications</h3>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Inbox</th>
                        <th>Actions</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="user-info">
                                <img src="avatar.png" alt="Avatar">
                                <p>Niki Zahra</p>
                            </div>
                        </td>
                        <td>Friended you as their companion!</td>
                        <td>
                            <button class="action-btn">View</button>
                            <button class="action-btn">Archive</button>
                            <button class="action-btn">Delete</button>
                        </td>
                        <td>nikizahra@gmail.com</td>
                    </tr>
                    <tr>
                        <td>
                            <div class="user-info">
                                <img src="avatar.png" alt="Avatar">
                                <p>CompaniON Admin</p>
                            </div>
                        </td>
                        <td>Type a bio in your profile</td>
                        <td>
                            <button class="action-btn">View</button>
                            <button class="action-btn">Archive</button>
                            <button class="action-btn">Delete</button>
                        </td>
                        <td>companionadmin@gmail.com</td>
                    </tr>
                    <!-- Add more rows as necessary -->
                </tbody>
            </table>
            <p>Nothing follows.</p>
        </div>
    </div>
</div>
</body>
</html>
