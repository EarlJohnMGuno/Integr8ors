<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your Identity</title>
    <link rel="stylesheet" href="verify.css">
</head>
<body>
    <div class="container">
    <header>
        <div class="logo">
            <h1>CompaniON</h1>  
        </div>
        <div class="nav">
            <input type="text" placeholder="What are you looking for?">
            <ul>

                <li><a href="companionprofile.php">Profile</a></li>                
                <li><a href="companionnotif.php">Notifications</a></li>
                <li><a href="verify.php">Verify</a></li>
                <li><a href="history.php">History</a></li>
            </ul>
        </div>
    </header>
        <main>
            <h2>Verify Your Identity</h2>
            <p>To continue using our platform and ensure security, we need to verify your identity. This process helps us confirm your account and protect our community from fraud or misuse.</p>

            <div class="guide">
                <h3>Step-by-Step Guide</h3>
                <ol>
                    <li>
                        <b>Step 1: Prepare Your Documents</b><br>
                        Before starting the verification process, make sure you have the following ready:
                        <ul>
                            <li>Government-issued ID (e.g., driver’s license, passport, or national ID card)</li>
                            <li>Good lighting for taking a clear selfie</li>
                            <li>Camera or smartphone to take photos</li>
                        </ul>
                    </li>
                    <li>
                        <b>Step 2: Upload the Front of Your ID</b><br>
                        Take a photo or upload an image of the front side of your government-issued ID. Make sure all details like your name, ID number, and expiration date are clearly visible.
                        <ul>
                            <li>Place the ID on a flat surface.</li>
                            <li>Ensure good lighting (avoid shadows or glares).</li>
                            <li>Focus on the entire ID and avoid cropping any part.</li>
                        </ul>
                    </li>
                    <li>
                        <b>Step 3: Take a Selfie with Your ID</b><br>
                        Take a selfie while holding your ID next to your face. Ensure both your face and the ID are clearly visible.
                        <ul>
                            <li>Hold your ID next to your face, ensuring your face and the ID are both visible.</li>
                            <li>Make sure your face is fully lit (avoid backlight or darkness).</li>
                            <li>Hold the ID steady so that the details are readable.</li>
                        </ul>
                    </li>
                    <li>
                        <b>Step 5: Submit for Verification</b><br>
                        Once all documents are uploaded, click the 'Submit for Verification' button. Our team will review your submission and notify you within 24-48 hours.
                    </li>
                </ol>
            </div>

            <div class="upload-section">
                <div class="upload-box">
                    <h4>Upload Your ID Documents</h4>
                    <p>Please upload a clear image of your government-issued ID.</p>
                    <button>Upload Front</button>
                    <button>Upload Back</button>
                </div>
                <div class="upload-box">
                    <h4>Upload a Selfie with Your ID</h4>
                    <p>Please upload a clear image of your government-issued ID.</p>
                    <button>Upload Front</button>
                    <button>Upload Back</button>
                </div>
            </div>

            <div class="submit-section">
                <input type="checkbox" id="terms">
                <label for="terms">I have read and agree to the Terms and Conditions and Privacy Policy.</label>
                <br>
                <button class="submit-button">Submit</button>
            </div>
        </main>
    </div>
</body>
</html>
