<?php
session_start();
include("connection.php");

if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$name = $_POST['email'];
		$pass = $_POST['password'];
		$sql="select * from users where email='".$name."' AND password='".$pass."'  ";
		$result=mysqli_query($data,$sql);
		$row=mysqli_fetch_array($result);



		if($row["usertype"]=="user")
		{
			$_SESSION['username']=$name;
			$_SESSION['usertype']="user";
			header("location:user.php");
		}

		elseif($row["usertype"]=="admin")
		{	
			$_SESSION['username']=$name;
			$_SESSION['usertype']="admin";
			header("location:admin.php");
		}

        elseif($row["usertype"]=="companion")
		{	
			$_SESSION['username']=$name;
			$_SESSION['usertype']="companion";
			header("location:Companion/companionprofile.php");
		}

		else
		{
			$message= "username or password do not match";
			$_SESSION['loginMessage']=$message;
			header("location:loginform.php");
		}
	}
?>
