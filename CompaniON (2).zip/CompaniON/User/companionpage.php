<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON</title>
    <link rel="stylesheet" href="companionpage.css">
</head>
<body>
<header>
        <div class="logo">
            <h1>CompaniON</h1>  
        </div>
        <div class="nav">
            <input type="text" placeholder="What are you looking for?">
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Companion</a></li>
                <li><a href="#">How it works</a></li>
                <li><a href="profilepage.php">Profile</a></li>
            </ul>
        </div>
    </header>

    <main>
        <section class="find-companion">
            <h2>Find your companion</h2>

            <div class="companion-card">
                <div class="companion-info">
                    <p>Available</p>
                    <p>Professional</p>
                    <span class="stars">★★★★★</span>
                </div>
                <button>View More...</button>
            </div>

            <div class="companion-card">
                <div class="companion-info">
                    <p>Available</p>
                    <p>Professional</p>
                    <span class="stars">★★★★☆</span>
                </div>
                <button>View More...</button>
            </div>

            <div class="companion-card">
                <div class="companion-info">
                    <p>Available</p>
                    <p>Professional</p>
                    <span class="stars">★★★★★</span>
                </div>
                <button>View More...</button>
            </div>

            <div class="companion-card">
                <div class="companion-info">
                    <p>Available</p>
                    <p>Professional</p>
                    <span class="stars">★★★★☆</span>
                </div>
                <button>View More...</button>
            </div>

            <p><a href="#">View More...</a></p>
        </section>

        <aside>
            <div class="filter">
                <h3>Filter by</h3>
                <!-- Filter options go here -->
                <div class="filter-option"></div>
                <div class="filter-option"></div>
            </div>

            <div class="recommended-places">
                <h3>Recommended Places</h3>
                <div class="place-card">
                    <p>Place Name</p>
                    <p>Description</p>
                    <button>View Place</button>
                </div>
                <div class="place-card">
                    <p>Place Name</p>
                    <p>Description</p>
                    <button>View Place</button>
                </div>
            </div>
        </aside>
    </main>

    <footer>
        <!-- Footer content here -->
    </footer>
</body>
</html>
