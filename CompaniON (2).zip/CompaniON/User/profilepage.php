<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON</title>
    <link rel="stylesheet" href="profilepage.css">
</head>
<body>
<div class="container">
    <header>
        <div class="logo">
            <h1>CompaniON</h1>  
        </div>
        <div class="nav">
            <input type="text" placeholder="What are you looking for?">
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Companion</a></li>
                <li><a href="#">How it works</a></li>
                <li><a href="profilepage.php">Profile</a></li>
            </ul>
        </div>
    </header>
    
    <!-- Main content container with flex layout -->
    <div class="main-content">
        <div class="left-column">
            <!-- Profile Section -->
            <div class="profile-section">
                <div class="profile-header">
                    <div class="profile-pic"></div>
                    <div class="profile-info">
                        <h2>USERNAME</h2>
                        <p>FULL NAME</p>
                        <p>Status: <span class="verified">Verified</span></p>
                        <a href="editprofile.php">
                            <button>Edit Profile</button>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Recent Activity Section -->
            <div class="recent-activity">
                <h3>Recent Activity</h3>
                <div class="activity-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Companion's Info</th>
                                <th>Schedule</th>
                                <th>Actions</th>
                                <th>Status</th>
                                <th>Reviews</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Repeat the table rows as necessary -->
                            <tr>
                                <td>Info</td>
                                <td>Schedule</td>
                                <td>Actions</td>
                                <td>Pending</td>
                                <td>Review</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Notifications Section -->
        <div class="right-column">
            <div class="notifications">
                <h3>Notifications</h3>
                <ul>
                    <li>Notification 1</li>
                    <li>Notification 2</li>
                    <li>Notification 3</li>
                </ul>
            </div>
        </div>
    </div>
</div>
</body>
</html>
