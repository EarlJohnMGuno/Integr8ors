<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rating Form</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container mt-5">
    <div class="card p-4">
      <h5 class="card-title">How was your experience?</h5>
      <div class="stars mb-3">
        <span class="star" data-value="1">&#9733;</span>
        <span class="star" data-value="2">&#9733;</span>
        <span class="star" data-value="3">&#9733;</span>
        <span class="star" data-value="4">&#9733;</span>
        <span class="star" data-value="5">&#9733;</span>
      </div>
      <div class="form-group mb-3">
        <label for="comments">Comments and Suggestion</label>
        <textarea id="comments" class="form-control" rows="3" maxlength="255" placeholder="Enter your feedback"></textarea>
      </div>
      <div class="d-flex justify-content-end">
        <button class="btn btn-success me-2">Save</button>
        <button class="btn btn-danger">Exit</button>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="scripts.js"></script>
</body>
</html>
