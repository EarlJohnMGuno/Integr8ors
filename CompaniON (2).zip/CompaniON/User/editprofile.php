<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="user.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <h1>CompaniON</h1>
            </div>
            <div class="nav">
                <input type="text" placeholder="What are you looking for?">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Companion</a></li>
                    <li><a href="#">How it works</a></li>
                    <li><a href="profilepage.php">Profile</a></li>
                </ul>
            </div>
        </header>

        <section class="edit-profile">
            <h2>Edit Profile</h2>
            <form action="">
                <div class="form-group">
                    <input type="text" placeholder="First Name">
                    <input type="text" placeholder="Last Name">
                </div>

                <div class="form-group">
                    <input type="email" placeholder="Email">
                    <input type="text" placeholder="Phone Number">
                </div>

                <div class="form-group">
                    <input type="date" placeholder="Date of Birth">
                    <select>
                        <option value="" disabled selected>Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                    <input type="text" placeholder="Country">
                </div>

                <div class="form-group bio">
                    <textarea placeholder="Bio" maxlength="255"></textarea>
                
                </div>

                <div class="form-group buttons">
                    <button type="button" class="change-username">Change Username</button>
                    <button type="button" class="change-password">Change Password</button>
                </div>

                <div class="form-group action-buttons">
                    <button type="submit" class="save">Save</button>
                    <button type="button" class="exit">Exit</button>
                </div>
            </form>
        </section>
    </div>
</body>
</html>
