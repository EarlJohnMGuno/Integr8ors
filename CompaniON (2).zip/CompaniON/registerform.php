<?php
    include("connection.php");
    include("home.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center vh-100">
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-lg p-3 mb-5 bg-white rounded">
                    <div class="card-body">
                        <h3 class="card-title text-center mb-4">Register!</h3>
                        
                        <?php
                            if (isset($_POST["submit"])) {
                                $name = $_POST["name"];
                                $age = $_POST["age"];
                                $gender = $_POST["gender"];
                                $email = $_POST["email"];
                                $password = $_POST["password"];
                                $passwordRepeat = $_POST["repeat_password"];
                                
                                $passwordHash = password_hash($password, PASSWORD_DEFAULT);

                                $errors = array();
                                
                                // Check for empty fields
                                if (empty($name) OR empty($age) OR empty($gender) OR empty($email) OR empty($password) OR empty($passwordRepeat)) {
                                    array_push($errors, "All fields are required");
                                }
                                
                                // Validate email format
                                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                    array_push($errors, "Email is not valid");
                                }
                                
                                // Validate password length
                                if (strlen($password) < 8) {
                                    array_push($errors, "Password must be at least 8 characters long");
                                }
                                
                                // Check if passwords match
                                if ($password !== $passwordRepeat) {
                                    array_push($errors, "Passwords do not match");
                                }
                                
                                // Check if email already exists
                                require_once "connection.php";
                                $sql = "SELECT * FROM users WHERE email = '$email'";
                                $result = mysqli_query($conn, $sql);
                                $rowCount = mysqli_num_rows($result);
                                if ($rowCount > 0) {
                                    array_push($errors, "Email already exists!");
                                }
                                
                                // Display errors or insert data
                                if (count($errors) > 0) {
                                    foreach ($errors as $error) {
                                        echo "<div class='alert alert-danger'>$error</div>";
                                    }
                                } else {
                                    $sql = "INSERT INTO users (name, age, gender, email, password) VALUES (?, ?, ?, ?, ?)";
                                    $stmt = mysqli_stmt_init($conn);
                                    $prepareStmt = mysqli_stmt_prepare($stmt, $sql);
                                    if ($prepareStmt) {
                                        mysqli_stmt_bind_param($stmt, "sisss", $name, $age, $gender, $email, $passwordHash);
                                        mysqli_stmt_execute($stmt);
                                        echo "<div class='alert alert-success'>You are registered successfully.</div>";
                                    } else {
                                        die("Something went wrong");
                                    }
                                }
                            }
                        ?>
                        
                        <form name="form" action="registerform.php" method="POST">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" name="name" id="name" class="form-control" placeholder="Enter your Name" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="age">Age</label>
                                <input type="text" name="age" id="age" class="form-control" placeholder="Enter your Age" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="gender">Gender</label>
                                <select name="gender" id="gender" class="form-control" required>
                                    <option value="" disabled selected>Select your Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" name="email" id="email" class="form-control" placeholder="Enter your Email" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="password" class="form-control" placeholder="Enter your Password" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="repeat_password">Confirm Password</label>
                                <input type="password" name="repeat_password" id="repeat_password" class="form-control" placeholder="Repeat your Password" required>
                            </div>
                            
                            <button type="submit" name="submit" class="btn btn-primary btn-block">Submit</button>    
                        </form>
                        
                        <div class="mt-3">
                            <p>Already Registered? <a href="loginform.php">Login Here</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
