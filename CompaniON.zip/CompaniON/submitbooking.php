<?php
// Start the session at the very beginning of the script
session_start();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request method.");
}

// Debugging output for session values
if (!isset($_SESSION['companion_id']) || !isset($_SESSION['user_id'])) {
    die("User or companion ID not set in session.");
}

// Accessing session variables
$user_id = $_SESSION['user_id'];         // Should be the primary key ID from user_table
$companion_id = $_SESSION['companion_id']; // Should be the primary key ID from companion_table

// Database connection
$host = 'localhost';
$dbname = 'companion';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("Database connection error: " . $e->getMessage());
    die("An error occurred while connecting to the database. Please try again later.");
}

// Getting booking details from POST request
$preferred_date = $_POST['preferred_date'] ?? null;
$preferred_time = $_POST['preferred_time'] ?? null;
$duration = $_POST['duration'] ?? null;
$location = $_POST['location_place'] ?? null;
$event_type = $_POST['event_type'] ?? null;
$special_requests = $_POST['special_requests'] ?? null;

// Validate user_id, companion_id, and other required fields
if ($user_id && $companion_id && !empty($preferred_date) && !empty($preferred_time) && $duration > 0) {
    try {
        // Insert booking with verified user_id and companion_id
        $query = $pdo->prepare("INSERT INTO bookings (user_id, companion_id, preferred_date, preferred_time, duration, location, event_type, special_requests) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        
        // Debugging output to verify values before insertion
        echo $user_id, $companion_id, $preferred_date, $preferred_time, $duration, $location, $event_type, $special_requests;
        
        // Execute insert query
        $query->execute([$user_id, $companion_id, $preferred_date, $preferred_time, $duration, $location, $event_type, $special_requests]);
        
        // Redirect on successful insert
        header("Location: success.php");
        exit();
    } catch (PDOException $e) {
        error_log("Database error on booking insert: " . $e->getMessage());
        die("An error occurred while processing your booking. Please try again later.");
    }
} else {
    die("Invalid data. Please check your input and try again.");
}
?>
