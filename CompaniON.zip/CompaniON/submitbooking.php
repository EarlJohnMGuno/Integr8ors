<?php
// Start the session at the very beginning of the script
session_start();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request method.");
}

// Debugging output for session values
if (!isset($_SESSION['companion_id']) || !isset($_SESSION['user_id'])) {
    die("User or companion ID not set in session.");
}

// Accessing session variables
$user_id = $_SESSION['user_id'];         // Should be the primary key ID from user_table
$companion_id = $_SESSION['companion_id']; // Should be the primary key ID from companion_table

// Database connection
$host = 'localhost';
$dbname = 'companion';
$username = 'root';
$password = '';

// Create connection using MySQLi
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Getting booking details from POST request
$preferred_date = $_POST['preferred_date'] ?? null;
$preferred_time = $_POST['preferred_time'] ?? null;
$duration = (int)($_POST['duration'] ?? 0); // Ensure duration is an integer
$location = $_POST['location_place'] ?? null;
$event_type = $_POST['event_type'] ?? null;
$special_requests = $_POST['special_requests'] ?? null;
// Getting booking details from POST request
$preferred_date = $_POST['preferred_date'] ?? null;
echo "Preferred Date from POST: " . htmlspecialchars($preferred_date); // Debug output

// Validate user_id, companion_id, and other required fields
if ($user_id && $companion_id && !empty($preferred_date) && !empty($preferred_time) && $duration > 0) {
    // Attempt to create a DateTime object from the preferred date
    $dateTime = DateTime::createFromFormat('Y-m-d', $preferred_date);

    // If the date format is not correct, try to create from other common formats
    if (!$dateTime) {
        // Try another common format, e.g., 'm/d/Y' or 'd/m/Y'
        $dateTime = DateTime::createFromFormat('m/d/Y', $preferred_date);
        if (!$dateTime) {
            $dateTime = DateTime::createFromFormat('d/m/Y', $preferred_date);
        }
    }

    // Check if we successfully created a DateTime object
    if ($dateTime) {
        // Format the date to 'Y-m-d'
        $preferred_date = $dateTime->format('Y-m-d');
    } else {
        die("Invalid date format. Please use YYYY-MM-DD. Received: " . htmlspecialchars($preferred_date));
    }

    // Proceed with the rest of the booking logic...
    $stmt = $conn->prepare("INSERT INTO bookings (user_id, companion_id, preferred_date, preferred_time, duration, location_PLACE, event_type, special_requests) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    if ($stmt === false) {
        error_log("Prepare failed: " . $conn->error);
        die("An error occurred while preparing the statement. Please try again later.");
    }

    $stmt->bind_param("iississs", $user_id, $companion_id, $preferred_date, $preferred_time, $duration, $location, $event_type, $special_requests);

    // Execute the statement
    if (!$stmt->execute()) {
        error_log("Execution error: " . $stmt->error);
        die("An error occurred while processing your booking. Please try again later.");
    }

    // Redirect on successful insert
    header("Location: rentcompanion.php");
    exit();
} else {
    die("Invalid data. Please check your input and try again.");
}


?>
