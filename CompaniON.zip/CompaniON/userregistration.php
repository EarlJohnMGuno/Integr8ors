<?php
// Database configuration
$host = "localhost";
$dbname = "CompaniON";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $firstname = htmlspecialchars($_POST['firstname']);
    $lastname = htmlspecialchars($_POST['lastname']);
    $date_of_birth = $_POST['date_of_birth']; // Directly get the YYYY-MM-DD formatted date
    $gender = $_POST['gender'];
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $contactnumber = htmlspecialchars($_POST['contactnumber']);
    $address = htmlspecialchars($_POST['address']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        echo "Passwords do not match!";
        exit;
    }

    // Calculate age
    $dob = new DateTime($date_of_birth); // Use the correct variable
    $today = new DateTime();
    $age = $today->diff($dob)->y;

    if ($age < 18) {
        echo "You must be at least 18 years old to register.";
        exit;
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $conn->prepare("INSERT INTO users (firstname, lastname, date_of_birth, age, gender, email, contactnumber, address, password) 
                                VALUES (:firstname, :lastname, :date_of_birth, :age, :gender, :email, :contactnumber, :address, :password)");
        $stmt->bindParam(':firstname', $firstname);
        $stmt->bindParam(':lastname', $lastname);
        $stmt->bindParam(':date_of_birth', $date_of_birth); // Correctly bind the formatted date
        $stmt->bindParam(':age', $age); // Bind the age variable
        $stmt->bindParam(':gender', $gender);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':contactnumber', $contactnumber);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':password', $hashed_password);
        
        $stmt->execute();

        echo "Registration successful!";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
