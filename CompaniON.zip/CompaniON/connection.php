<?php
$host = "localhost";  // or the server IP address
$db_user = "root";    // MySQL username (default is 'root' for XAMPP)
$db_pass = "";        // MySQL password (default is empty for XAMPP)
$db_name = "companion1";  // Replace with your database name

// Create a connection
$data = mysqli_connect($host, $db_user, $db_pass, $db_name);

// Check the connection
if (!$data) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
