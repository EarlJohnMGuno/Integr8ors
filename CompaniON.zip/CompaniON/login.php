<?php
session_start(); 
include("connection.php"); 

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($data, trim($_POST['email']));
    $pass = trim($_POST['password']);
    
    if (empty($email) || empty($pass)) {
        $_SESSION['loginMessage'] = "Email or password cannot be empty!";
        exit();
    }

    // Prepare the SQL query using prepared statements to prevent SQL injection
    $sql = $data->prepare("SELECT email, password, usertype FROM users WHERE email = ?");
    $sql->bind_param("s", $email);
    $sql->execute();
    $result = $sql->get_result();

    // Check if a result was returned and if the email exists
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_array($result);

        // Debugging: Check if the row contains the correct data
        echo "User found: " . htmlspecialchars($row['email']) . "<br>";

        // Debugging: Ensure that the correct password column is used
        if (isset($row['password'])) {
            echo "Hashed password from database: " . htmlspecialchars($row['password']) . "<br>";

            // Verify the hashed password
            if (password_verify($pass, $row['password'])) {
                echo "Password matches!<br>"; // Debugging: Password matches message

                // Check the user type and redirect accordingly
                if ($row["usertype"] == "user") {
                    $_SESSION['email'] = $email;
                    $_SESSION['usertype'] = "user";
                    exit();
					
                } elseif ($row["usertype"] == "admin") {
                    $_SESSION['email'] = $email;
                    $_SESSION['usertype'] = "admin";
                    exit();
                }
            } else {
                echo "Password does not match!<br>";
                $message = "Username or password do not match";
                $_SESSION['loginMessage'] = $message;
                exit();
            }
        } else {
            echo "Password field does not exist in the fetched row!<br>";
            exit();
        }
    } else {
        echo "No user found with that email!<br>";

        $message = "Username or password do not match";
        $_SESSION['loginMessage'] = $message;
        exit();
    }
}
?>