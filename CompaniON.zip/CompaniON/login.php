<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "companion";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare the SQL statement
    $stmt = $conn->prepare("SELECT password, usertype, id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashedPassword, $usertype, $id);
        $stmt->fetch();

        // Verify password
        if (password_verify($password, $hashedPassword)) {
            $_SESSION['user_id'] = $id;
            $_SESSION['usertype'] = $usertype;
            // Redirect based on usertype
            if ($usertype == "User") {
                header("Location: index.html");
                exit();
            } elseif ($usertype == "admin") {
                header("Location: admin.php");
                exit();
            } elseif ($usertype == "Companion") {
                header("Location: companion1/companionprofile.php");
                exit();
            }
        } else {
            $_SESSION['loginMessage'] = "Incorrect password.";
            header("Location: /loginform.php");
            exit();
        }
    } else {
        $_SESSION['loginMessage'] = "No user found with that email.";
        header("Location: /loginform.php");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
