<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Account - CompaniON</title>
    <link rel="stylesheet" href="registerform.css"> <!-- Link to your external CSS -->
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>CompaniON</h1>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="What are you looking for?">
            </div>
            <nav>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Companion</a></li>
                    <li><a href="#">How it works</a></li>
                    <li><a href="#" class="login-btn">Login</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="register-container">
        <form action="registration.php" method="POST" class="register-form">
            <h2>Register Account</h2>
            <div class="form-row">
                <input type="text" name="firstname" placeholder="First Name" required>
                <input type="text" name="lastname" placeholder="Last Name" required>
            </div>
            <div class="form-row">
                <input type="number" name="age" placeholder="Age" required>
                <select name="gender" required>
                    <option value="" disabled selected>Gender:</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <input type="text" name="contactnumber" placeholder="Contact Number" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="address" placeholder="Address" required>
            <select name="availabilty" required>
                <option value="" disabled selected>Availabilty:</option>
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Friday">Friday</option>
                <option value="Saturday">Saturday</option>
                <option value="Sunday">Sunday</option>
            </select>            
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>

            <button type="submit">Register</button>
            <p>Already have an account? <a href="loginform.php">Login here</a></p>
        </form>
    </div>
</body>
</html>
