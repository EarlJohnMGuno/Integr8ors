<?php
// Start the session at the very beginning of the script
session_start();

// Database connection
$servername = "localhost"; 
$username = "root";       
$password = "";            
$dbname = "companion";     

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the username from the URL
if (isset($_GET['username'])) {
    $username = $_GET['username'];
} else {
    // Redirect or show error if no username is provided
    echo "No companion selected.";
    header("Location: rentcompanion.php");
    exit;
}

// Fetch companion details, including companion_id
$sql = "SELECT companion_id, firstname, lastname, email, interestshobbies, bio, availability 
        FROM companion_table 
        WHERE CONCAT(firstname, '_', lastname) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $companion = $result->fetch_assoc(); // Fetch data into $companion
    $companion_id = $companion['companion_id']; // Get companion ID
// Check if the companion exists

    // Store username and companion ID in the session
    $_SESSION['username'] = $username;
    $_SESSION['companion_id'] = $companion_id;

    // Process availability
    $availability_days = $companion['availability'];
    $availability_days_array = explode(',', $availability_days);


$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css">
    <link rel="stylesheet" href="companiondetails.css" />
</head>
<body>
    <header>
        <div class="logo">
          <img src="Assets/logo.png" alt="CompaniON Logo" />
        </div>
  
        <div class="nav">
          <div class="search-bar">
            <input placeholder="What are you looking for?" type="text" />
          </div>
          <ul>
            <li><a href="index.html">Home </a></li>
            <li><a href="rentcompanion.php">Companion </a></li>
            <li><a href="howitworks.html">How it works </a></li>
            <li><a href="">Profile</a></li>
          </ul>
        </div>
      </header>

    <div class="container">
        <div class="header"><?php echo $companion['firstname'] . ' ' . $companion['lastname']; ?></div>
       
        <p><?php echo $companion['bio']; ?></p>

        <div class="header">Availability Calendar</div>
        <div class="availability-calendar" id="calendar"></div>
        <div class="availability-details">
            <h2 class="section-title">Interests & Hobbies</h2>
            <ul>
                <?php
                // Split the hobbies string into a list
                $hobbies = explode(',', $companion['interestshobbies']);
                foreach ($hobbies as $hobby) {
                    echo '<li><strong>' . trim($hobby) . '</strong></li>';
                }
                ?>
            </ul>

            <h2 class="section-title">Contact Information</h2>
            <ul>
                <li><strong>Preferred Contact</strong>: In-app messaging</li>
                <li><strong>Direct Email</strong>: <a href="mailto:<?php echo $companion['email']; ?>"><?php echo $companion['email']; ?></a></li>
            </ul>
        </div>

        <div class="feedbacks">
            <div class="header">Feedback</div>

            <!-- Static feedback for now; you can update this to pull from the database later -->
            <div class="feedback-item">
                <img src="Assets/5.png" alt="User profile picture">
                <div class="feedback-text">
                    <p><strong>Glycella Yvona Virtucio</strong></p>
                    <p>She is very easy to talk to and we had a great time exploring the local parks</p>
                </div>
                <div class="feedback-stars">
                    <i class="fas fa-star"></i>
                    <i> 5.0</i>
                </div>
            </div>
            <div class="feedback-item">
                <img src="Assets/6.png" alt="User profile picture">
                <div class="feedback-text">
                    <p><strong>Kylle Mark Paragas</strong></p>
                    <p>Great experience! Very friendly and fun to be around</p>
                </div>
                <div class="feedback-stars">
                    <i class="fas fa-star"></i>
                    <i> 5.0</i>
                </div>
            </div>
        </div>

        <div class="buttons">
            <a href="rentcompanion.php"><button class="button">Back</button></a> 
            <a href="bookingdetails.php"><button class="button">Book Now</button></a>
        </div>
    </div>

    <script>
        // Pass the availability days array to JavaScript
        var availabilityDays = <?php echo json_encode($availability_days_array); ?>;
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js"></script>
    <script>
        $(document).ready(function () {
            // Function to get all dates for a specific day of the week in the current month
            function getDatesForDay(dayName) {
                const daysOfWeek = {
                    'Sunday': 1,
                    'Monday': 2,
                    'Tuesday': 3,
                    'Wednesday': 4,
                    'Thursday': 5,
                    'Friday': 6,
                    'Saturday': 0
                };
                const today = new Date();
                const year = today.getFullYear();
                const month = today.getMonth();

                const dayIndex = daysOfWeek[dayName.trim()];
                let dates = [];
                let date = new Date(year, month, 1);

                while (date.getDay() !== dayIndex) {
                    date.setDate(date.getDate() + 1);
                }

                while (date.getMonth() === month) {
                    dates.push(new Date(date));
                    date.setDate(date.getDate() + 7);
                }

                return dates;
            }

            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month'
                },
                selectable: false,
                events: function (start, end, timezone, callback) {
                    var events = [];

                    availabilityDays.forEach(function(dayName) {
                        var dates = getDatesForDay(dayName);
                        dates.forEach(function(date) {
                            events.push({
                                start: date.toISOString().slice(0, 10),
                                allDay: true,
                                rendering: 'background',
                                color: '#28a745'
                            });
                        });
                    });

                    callback(events);
                },
                editable: false
            });
        });
    </script>
</body>
</html>
