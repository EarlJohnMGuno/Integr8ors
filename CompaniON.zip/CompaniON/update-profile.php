<?php
session_start();

// Database connection settings
$host = "localhost";
$dbname = "companion";
$username = "root";
$password = "";

// Create database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user is logged in
$user_Id = $_SESSION['user_id'] ?? null;
if ($user_Id === null) {
    die("User not logged in.");
}

// Retrieve current profile data
$sql = "SELECT firstname, lastname, email, contactnumber, date_of_birth, gender, address, bio FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_Id);
$stmt->execute();
$stmt->bind_result($currentFirstName, $currentLastName, $currentEmail, $currentContactNumber, $currentDOB, $currentGender, $currentAddress, $currentBio);
$stmt->fetch();
$stmt->close();

// Retrieve form data, using existing data if input is empty
$firstName = !empty($_POST['firstName']) ? $_POST['firstName'] : $currentFirstName;
$lastName = !empty($_POST['lastName']) ? $_POST['lastName'] : $currentLastName;
$email = !empty($_POST['email']) ? $_POST['email'] : $currentEmail;
$contactNumber = !empty($_POST['contactNumber']) ? $_POST['contactNumber'] : $currentContactNumber;
$dob = !empty($_POST['dob']) ? $_POST['dob'] : $currentDOB;
$gender = isset($_POST['gender']) && $_POST['gender'] !== "" ? $_POST['gender'] : $currentGender;
$address = !empty($_POST['address']) ? $_POST['address'] : $currentAddress;
$bio = !empty($_POST['bio']) ? $_POST['bio'] : $currentBio;

// Prepare SQL statement to update profile
$sql = "UPDATE users SET 
            firstname = ?, 
            lastname = ?, 
            email = ?, 
            contactnumber = ?, 
            date_of_birth = ?, 
            gender = ?, 
            address = ?, 
            bio = ? 
        WHERE id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssssi", $firstName, $lastName, $email, $contactNumber, $dob, $gender, $address, $bio, $user_Id);

// Execute the statement and check for success
if ($stmt->execute()) {
    echo "Profile updated successfully";
} else {
    echo "Error updating profile: " . $conn->error;
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
