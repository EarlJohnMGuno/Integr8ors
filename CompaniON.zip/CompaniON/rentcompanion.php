<?php
// Connect to the database
$servername = "localhost"; // Or your DB host
$username = "root";        // DB username
$password = "";            // DB password
$dbname = "companion"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch companions data from the database
$sql = "SELECT firstname, lastname, bio FROM companion_table";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="rentcompanion.css" />
</head>
<body>
    <header>
        <div class="logo">
            <img src="Assets/logo.png" alt="CompaniON Logo" />
        </div>

        <div class="nav">
            <div class="search-bar">
                <input placeholder="What are you looking for?" type="text" />
            </div>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="rentcompanion.php">Companion</a></li>
                <li><a href="howitworks.html">How it works</a></li>
                <li><a href="generaluserprofile.php">Profile</a></li>
            </ul>
        </div>
    </header>

    <div class="container">
        <div class="left-column">
            <h2>Find your companion</h2>

            <?php
            if ($result->num_rows > 0) {
                // Output data for each row
                while($row = $result->fetch_assoc()) {
                    $username = strtolower($row["firstname"] . '_' . $row["lastname"]);
                    echo '
                    <div class="companion-card">
                        <h4>@' . $username . '</h4>
                        <p>' . $row["bio"] . '</p>
                        <a href="companiondetails.php?username=' . $username . '">
                            <button>Book Now</button>
                        </a>
                    </div>';
                }
             
            } else {
                echo "<p>No companions found</p>";
            }

            // Close the connection
            $conn->close();
            ?>
        </div>

        <div class="right-column">
            <div class="filter">
                <h3>Filter by</h3>
                <button>Location</button>
                <button>Age</button>
                <button>Availability</button>
            </div>
            <div class="recommended">
    <h3>Recommended Places</h3>
  
    <!-- Place 1 -->
    <div class="place">
      <img alt="Placeholder image for recommended place" height="150" src="Assets/smlipa.jpg" width="300"/>
      <h4>SM Lipa City</h4>
      <p>
        SM City Lipa is the region’s go-to hub for shopping, dining, and entertainment. With its wide array of fashion boutiques, restaurants, supermarkets, and recreational spaces, it caters to the diverse needs of individuals and families.  </p>
      <button onclick="openModal('modal1')">View Details</button>
    </div>
    
    <!-- Modal for Place 1 -->
    <div id="modal1" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('modal1')">&times;</span>
            
            <div class="event-header">
                <img src="Assets/smmlipaa.png" alt="Event 1 Image">
                <div class="event-details">
                    <h1>SM City Lipa</h1>
                    <p>SM City Lipa is the region’s go-to hub for shopping, dining, and entertainment. With its wide array of fashion boutiques, restaurants, supermarkets, and recreational spaces, it caters to the diverse needs of individuals and families. Known for hosting seasonal events, sales, and activities, SM Lipa offers more than just shopping—it’s a lifestyle destination.</p>
                </div>
            </div>
            
            <div class="event-description">
                From cinemas and arcades to cafés and food courts, SM Lipa ensures that every visit is a fun-filled experience. Whether you're running errands, enjoying a meal, or catching a movie, SM City Lipa has it all under one roof! </div>
            
            
                <div class="event-images">
                    <img src="Assets/smlipa.jpg" alt="Event Image 1">
                    <img src="Assets/sm2.jpg" alt="Event Image 2">
                    <img src="Assets/sm3.jpg" alt="Event Image 3">
                </div>
        </div>
    </div>
    
    <!-- Place 2 -->
    <div class="place">
      <img alt="Placeholder image for recommended place" height="150" src="Assets/rob.jpg" width="300"/>
      <h4>Place 2</h4>
      <p>
        The Outlets at Lipa is a premier shopping and lifestyle destination located in the heart of Batangas.      </p>
      <button onclick="openModal('modal2')">View Details</button>
    </div>  
    
    <!-- Modal for Place 2 -->
    <div id="modal2" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('modal2')">&times;</span>
            
            <div class="event-header">
                <img src="Assets/funday.jpg" alt="Event 1 Image">
                <div class="event-details">
                    <h1>The Outlets at Lipa</h1>
                    <p>The Outlets at Lipa is a premier shopping and lifestyle destination located in the heart of Batangas. Known for its open-air layout and year-round discounts, it offers a variety of local and international brands at outlet prices. From fashion, footwear, and sportswear to home essentials and electronics, there’s something for everyone.</p>
                </div>
            </div>
            
            <div class="event-description">
                Beyond shopping, The Outlets at Lipa features dining options, recreational spaces, and events areas, making it a perfect venue for family outings and gatherings. Whether you're looking for great deals, delicious meals, or a day of leisure, The Outlets at Lipa promises a refreshing retail experience with something for every lifestyle.</div>
           
            
            <div class="event-images">
                <img src="Assets/field.jpg" alt="Event Image 1">
                <img src="Assets/outlets2.png" alt="Event Image 2">
                <img src="Assets/outlets3.png" alt="Event Image 3">
            </div>
        </div>
    </div>
        </div>
    </div>


 </div>
</div>
</div>
</div>
<script>
    function openModal(modalId) {
    document.getElementById(modalId).style.display = "flex";
}

// Function to close modal
function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none";
}

// Close the modal if the user clicks anywhere outside of the modal content
window.onclick = function(event) {
    var modals = document.getElementsByClassName('modal');
    for (let i = 0; i < modals.length; i++) {
        if (event.target == modals[i]) {
            modals[i].style.display = "none";
        }
    }
}
</script>
</body>
</html>