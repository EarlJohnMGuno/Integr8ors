<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent A Companion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="top-navigation">
        <div class="logo">Logo</div>
        <nav class="menu">
            <a href="homepage.php" class="active">Home</a>
            <a href="howitworks.php">How It Works</a>
            <a href="rentaldetails.php">Rental Details</a>
            <a href="whychooseus.php">Why Choose Us</a>
            <a href="testimonials.php">Testimonials</a>
            <a>|</a>
            <a href="registerform.php">Register</a>
        </nav>
        <a class="button" href="loginform.php">Log In</a>
    </nav>

</body>
</html>
