<?php
include '../connection.php';

session_start();
$user_id = $_SESSION['user_id']; // Get user ID from session
$usertype = $_SESSION['usertype']; // Get usertype from session

// Check if the user is a companion
if ($usertype === 'Companion') {
    // Fetch booking details for the companion
    $sql = "SELECT u.id AS user_id, u.firstname AS name, u.email, b.special_requests, b.created_at 
            FROM bookings AS b
            JOIN users_table AS u ON b.user_id = u.id
            WHERE b.companion_id = ?";


    // Prepare and execute the statement
    $stmt = $data->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON Notifications</title>
    <link rel="stylesheet" href="companionnotif.css">
</head>
<body>
<div class="container">
    <header>
        <div class="logo">
            <h1>CompaniON</h1>
        </div>
        <div class="nav">
            <input type="text" placeholder="What are you looking for?">
            <ul>
                <li><a href="companionprofile.php">Profile</a></li>
                <li><a href="companionnotif.php">Notifications</a></li>
                <li><a href="verify.php">Verify</a></li>
                <li><a href="history.php">History</a></li>
            </ul>
        </div>
    </header>

    <!-- Main Section -->
    <div class="main">
        <div class="menu">
            <h3>Menu</h3>
            <button class="menu-item active">Notifications</button>
            <button class="menu-item">Archives</button>
            <button class="menu-item">Deleted</button>
        </div>

        <!-- Notifications Section -->
        <div class="notifications-section">
            <h3>Notifications</h3>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Inbox</th>
                        <th>Actions</th>
                        <th>Email</th>
                    
                    </tr>
                </thead>
                <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td><div class='user-info'><img src='avatar.png' alt='Avatar'><p>" . htmlspecialchars($row['name']) . "</p></div></td>";
                        echo "<td>" . htmlspecialchars($row['special_requests']) . "</td>";
                        
                        // Use the user_id value here for the "View" link
                        echo "<td>
                                <a href='viewnotif.php?user_id=" . $row['user_id'] . "' class='action-btn'>View</a>
                                <button class='action-btn'>Archive</button>
                                <button class='action-btn'>Delete</button>
                            </td>";
                        
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No notifications found.</td></tr>";
                }
                ?>


                </tbody>
            </table>
        </div>
    </div>
</div>



<?php
    // Close connection
    $stmt->close();
    $data->close();
} else {
    echo "You are not authorized to view this page.";
}
?>
</body>
</html>
