<!-- To do 
 -Archives
 -Delete
  -->



<?php
include '../connection.php';

session_start(); 

$user_id = $_SESSION['user_id']; // Assuming companion_id is stored in session

// Query to get bookings only for the logged-in companion
$sql = "SELECT bookings.user_id, users_table.firstname, users_table.lastname, users_table.email
        FROM bookings
        JOIN users_table ON bookings.user_id = users_table.user_id
        WHERE bookings.companion_id = ?";
$stmt = $data->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON Notifications</title>
    <link rel="stylesheet" href="companionnotif.css">
</head>
<body>
<div class="container">
    <header>
        <div class="logo">
            <h1>CompaniON</h1>
        </div>
        <div class="nav">
            <input type="text" placeholder="What are you looking for?">
            <ul>
                <li><a href="companionprofile.php">Profile</a></li>
                <li><a href="companionnotif.php">Notifications</a></li>
                <li><a href="verify.php">Verify</a></li>
                <li><a href="history.php">History</a></li>
            </ul>
        </div>
    </header>
    <div class="main">
        <div class="menu">
            <h3>Menu</h3>
            <button class="menu-item active">Notifications</button>
            <button class="menu-item">Archives</button>
            <button class="menu-item">Deleted</button>
        </div>

        <!-- Notifications Section -->
        <div class="notifications-section">
            <h3>Notifications</h3>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Inbox</th>
                        <th>Actions</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                // Display the results
                if ($result && $result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        // Combine first and last names
                        $fullName = htmlspecialchars($row['firstname']) . " " . htmlspecialchars($row['lastname']);
                        echo "<tr>";
                        echo "<td><div class='user-info'><img src='avatar.png' alt='Avatar'><p>" . $fullName . "</p></div></td>";
                        echo "<td>hired you as their companion</td>";
                        echo "<td>
                        <form action='viewnotif.php' method='GET' style='display:inline;'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['user_id']) . "'>
                            <button type='submit' class='action-btn'>View</button>
                        </form>
                        <form action='archive.php' method='POST' style='display:inline;'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['user_id']) . "'>
                            <button type='submit' class='action-btn'>Archive</button>
                        </form>
                        <form action='delete.php' method='POST' style='display:inline;'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['user_id']) . "'>
                            <button type='submit' class='action-btn'>Delete</button>
                        </form>

                            </td>";
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No notifications found.</td></tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
