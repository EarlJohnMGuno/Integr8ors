<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your Identity</title>
    <link rel="stylesheet" href="verify.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <h1>CompaniON</h1>  
            </div>
            <div class="nav">
                <input type="text" placeholder="What are you looking for?">
                <ul>
                    <li><a href="companionprofile.php">Profile</a></li>                
                    <li><a href="companionnotif.php">Notifications</a></li>
                    <li><a href="verify.php">Verify</a></li>
                    <li><a href="history.php">History</a></li>
                </ul>
            </div>
        </header>

        <main>
            <h2>Verify Your Identity</h2>
            <p>To continue using our platform and ensure security, we need to verify your identity. This process helps us confirm your account and protect our community from fraud or misuse.</p>

            <div class="guide">
                <h3>Step-by-Step Guide</h3>
                <ol>
                    <li>
                        <b>Step 1: Prepare Your Documents</b><br>
                        Before starting the verification process, make sure you have the following ready:
                        <ul>
                            <li>Government-issued ID (e.g., driver’s license, passport, or national ID card)</li>
                            <li>Good lighting for taking a clear selfie</li>
                            <li>Camera or smartphone to take photos</li>
                        </ul>
                    </li>
                    <li>
                        <b>Step 2: Upload the Front of Your ID</b><br>
                        Take a photo or upload an image of the front side of your government-issued ID. Make sure all details like your name, ID number, and expiration date are clearly visible.
                    </li>
                    <li>
                        <b>Step 3: Take a Selfie with Your ID</b><br>
                        Take a selfie while holding your ID next to your face. Ensure both your face and the ID are clearly visible.
                    </li>
                    <li>
                        <b>Step 4: Submit for Verification</b><br>
                        Once all documents are uploaded, click the 'Submit for Verification' button. Our team will review your submission and notify you within 24-48 hours.
                    </li>
                </ol>
            </div>

            <form action="upload_verification.php" method="post" enctype="multipart/form-data">
            <div class="upload-section">
                <!-- Upload for ID Documents -->
                <div class="upload-box">
                    <h4>Upload Your ID Documents</h4>
                    <p>Please upload a clear image of your government-issued ID.</p>
                    <input type="file" name="id_front" accept="image/*">
                    <input type="file" name="id_back" accept="image/*">
                </div>

                <!-- Upload for Selfie with ID -->
                <div class="upload-box">
                    <h4>Upload a Selfie with Your ID</h4>
                    <p>Please upload a clear selfie holding your government-issued ID.</p>
                    <input type="file" name="selfie_front" accept="image/*">
                    <input type="file" name="selfie_back" accept="image/*">
                </div>

                <div class="submit-section">
                    <input type="checkbox" id="terms" name="terms" required>
                    <label for="terms">I agree to the Terms and Conditions and Privacy Policy.</label>
                    <br>
                    <button type="submit" class="submit-button">Submit</button>
                </div>
            </div>
        </form>
        </main>
    </div>

    <!-- JavaScript to handle automatic form submission -->
    <script>
        // Trigger the file input when the button is clicked for ID uploads
        document.getElementById('file-id-front').addEventListener('change', function() {
            // You can handle file upload logic here if needed
        });
        
        document.getElementById('file-id-back').addEventListener('change', function() {
            // You can handle file upload logic here if needed
        });

        // Trigger the file input when the button is clicked for Selfie uploads
        document.getElementById('file-selfie-front').addEventListener('change', function() {
            // You can handle file upload logic here if needed
        });

        document.getElementById('file-selfie-back').addEventListener('change', function() {
            // You can handle file upload logic here if needed
        });
    </script>
</body>
</html>
