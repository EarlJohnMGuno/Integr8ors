<!-- Design
 companion profile
 events -->

<?php
session_start();
include("../connection.php");

if(!isset($_SESSION['user_id'])) {
    header("Location: ../loginform.php"); // Redirect if the user is not logged in
    exit();
}

// Fetching the user's first name, last name, status, and availability
$user_id = $_SESSION['user_id'];
$query = "SELECT firstname, lastname, status, availability FROM users WHERE id = '$user_id'";
$result = mysqli_query($data, $query);
$user = mysqli_fetch_assoc($result);

if($user) {
    $firstname = $user['firstname'];
    $lastname = $user['lastname'];
    $status = $user['status'];
    $availability = $user['availability'];
} else {
    $firstname = "Unknown";
    $lastname = "User";
    $status = "Not Verified";
    $availability = "Unavailable";
}

// Fetching top notifications (latest bookings) for the logged-in companion
$notif_query = "SELECT bookings.*, users_table.firstname AS client_firstname, users_table.lastname AS client_lastname 
                FROM bookings 
                JOIN users_table ON bookings.user_id = users_table.user_id 
                WHERE bookings.companion_id = '$user_id' 
                ORDER BY bookings.created_at DESC 
                LIMIT 3"; // Limit to top 3 notifications
$notif_result = mysqli_query($data, $notif_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON Profile</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Your custom CSS file -->
    <link rel="stylesheet" href="companionprofile.css">
</head>
<body>
<div class="container">
    <header>
        <div class="logo">
            <h1>CompaniON</h1>
        </div>
        <div class="nav">
            <input type="text" placeholder="What are you looking for?">
            <ul>
                <li><a href="companionprofile.php">Profile</a></li>                
                <li><a href="companionnotif.php">Notifications</a></li>
                <li><a href="verify.php">Verify</a></li>
                <li><a href="history.php">History</a></li>
            </ul>
        </div>
    </header>

    <!-- Profile Section -->
    <div class="profile-section">
        <div class="grid-container">
            <!-- Profile Header -->
            <div class="profile-header">
                <h1>Welcome, <?php echo htmlspecialchars($firstname . ' ' . $lastname); ?> 
                    <span class="verified">

                        <?php 
                        $status = trim(strtolower($user['status']));
  
                        echo $status == 'verified' ? '✔' : '✖'; ?>

                    </span>
                </h1>
                <p>Short description about yourself. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                <a href="editcompanionprofile.php">
                    <button class="edit-profile-btn btn btn-primary">Edit Profile</button>
                </a>
                <p class="status">Status: 
                    <span class="<?php echo $status == 'Verified' ? 'verified' : 'not-verified'; ?>">
                        <?php echo htmlspecialchars($status); ?>
                    </span>
                </p>
            </div>

            <!-- Notifications Section -->
            <div class="notifications-section">
                <h3>Top Notifications</h3>
                <?php
                if ($notif_result && mysqli_num_rows($notif_result) > 0) {
                    while ($notif = mysqli_fetch_assoc($notif_result)) {
                        $client_name = htmlspecialchars($notif['client_firstname']) . ' ' . htmlspecialchars($notif['client_lastname']);
                        echo "<div class='notification-item'>";
                        echo "<img src='avatar.png' alt='User Image'>";
                        echo "<p>$client_name hired you as their companion</p>";
                        echo "<button class='view-btn'>View</button>";
                        echo "<button class='archive-btn'>Archive</button>";
                        echo "<button class='delete-btn'>Delete</button>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No recent notifications.</p>";
                }
                ?>
                <form action="companionnotif.php" method="get">
                    <button type="submit" class="view-more-btn">View More...</button>
                </form>
            </div>

            <!-- Availability Section -->
            <div class="availability">
                <h3>Your Availability</h3>
                <p>Current Availability: <span id="availability-status"><?php echo htmlspecialchars($availability); ?></span></p>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#availabilityModal">
                    Update
                </button>
            </div>

            <div class="events">
                <h3>Events</h3>
                <div class="event-item">
                    <p>Social Gathering</p>
                    <p>Details about the event</p>
                </div>
                <div class="event-item">
                    <p>Social Gathering</p>
                    <p>Details about the event</p>
                </div>
                <button class="view-more-btn">View More...</button>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap Modal for Updating Availability -->
<div class="modal fade" id="availabilityModal" tabindex="-1" aria-labelledby="availabilityModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="availabilityModalLabel">Update Availability</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="updateavailability.php" method="POST">
                    <div class="mb-3">
                        <label for="availability" class="form-label">Set your availability:</label>
                        <select class="form-select" name="availability" id="availability">
                            <option value="Monday" <?php if ($availability == 'Monday') echo 'selected'; ?>>Monday</option>
                            <option value="Tuesday" <?php if ($availability == 'Tuesday') echo 'selected'; ?>>Tuesday</option>
                            <option value="Wednesday" <?php if ($availability == 'Wednesday') echo 'selected'; ?>>Wednesday</option>
                            <option value="Thursday" <?php if ($availability == 'Thursday') echo 'selected'; ?>>Thursday</option>
                            <option value="Friday" <?php if ($availability == 'Friday') echo 'selected'; ?>>Friday</option>
                            <option value="Saturday" <?php if ($availability == 'Saturday') echo 'selected'; ?>>Saturday</option>
                            <option value="Sunday" <?php if ($availability == 'Sunday') echo 'selected'; ?>>Sunday</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
