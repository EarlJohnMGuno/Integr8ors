<?php
include '../connection.php';
session_start();

// Check if user_id is set in POST
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];
    $companion_id = $_SESSION['user_id']; // Assuming companion_id is stored in session

    // Update the booking to mark it as archived
    $sql = "UPDATE bookings SET archived = 1 WHERE user_id = ? AND companion_id = ?";
    $stmt = $data->prepare($sql);
    $stmt->bind_param("ii", $user_id, $companion_id);

    if ($stmt->execute()) {
        // Success: redirect back to notifications page with a success message
        header("Location: companionnotif.php?message=Archived successfully");
    } else {
        // Error: redirect with an error message
        header("Location: companionnotif.php?message=Failed to archive");
    }

    $stmt->close();
} else {
    // If user_id is not set, redirect with an error
    header("Location: companionnotif.php?message=Invalid request");
}

$data->close();
?>
