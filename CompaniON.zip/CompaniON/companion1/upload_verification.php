<?php
session_start();
include("../connection.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../loginform.php"); // Redirect if the user is not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // File upload directory
    $uploadDir = "uploads/";

    // Create uploads directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Initialize variables for file paths
    $idFront = $idBack = $selfieFront = $selfieBack = null;

    // Function to handle file uploads
    function uploadFile($fileInputName, $uploadDir) {
        if ($_FILES[$fileInputName]['error'] === UPLOAD_ERR_OK) {
            $fileName = basename($_FILES[$fileInputName]['name']);
            $targetPath = $uploadDir . $fileName;

            // Sanitize file name
            $fileName = preg_replace("/[^a-zA-Z0-9.]/", "_", $fileName);
            $targetPath = $uploadDir . $fileName;

            if (move_uploaded_file($_FILES[$fileInputName]['tmp_name'], $targetPath)) {
                return $targetPath; // Return the path on success
            } else {
                return null; // Return null on failure
            }
        } else {
            return null; // Return null if there was an upload error
        }
    }

    // Handle uploads
    $idFront = uploadFile('id_front', $uploadDir);
    $idBack = uploadFile('id_back', $uploadDir);
    $selfieFront = uploadFile('selfie_front', $uploadDir);
    $selfieBack = uploadFile('selfie_back', $uploadDir);

    // Prepare and execute the SQL statement
    $sql = "UPDATE users SET id_front = ?, id_back = ?, selfie_front = ?, selfie_back = ? WHERE id = ?";
    $stmt = mysqli_prepare($data, $sql);
    mysqli_stmt_bind_param($stmt, 'ssssi', $idFront, $idBack, $selfieFront, $selfieBack, $user_id);

    if (mysqli_stmt_execute($stmt)) {
        echo "Verification details uploaded successfully!";
        // Redirect to the profile page or display success message
        // header("Location: companionprofile.php");
    } else {
        echo "Error: " . mysqli_error($data);
    }

    // Close the statement
    mysqli_stmt_close($stmt);
}
?>
