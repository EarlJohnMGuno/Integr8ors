<?php
$host = 'localhost';
$dbname = 'companion';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error connecting to the database: " . $e->getMessage());
}

// Fetch profile data by ID
$profile_id = isset($_GET['profile_id']) ? $_GET['profile_id'] : 1; // Assuming profile_id is passed via GET method

$query = $pdo->prepare("SELECT * FROM users WHERE ID = :id");
$query->execute(['id' => $profile_id]);
$profile = $query->fetch(PDO::FETCH_ASSOC);

if (!$profile) {
    die("Profile not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Companion Profile</title>
    <link rel="stylesheet" href="editcompanionprofile.css">
</head>
<body>
<div class="container">
<header>
    <div class="logo">
        <h1>CompaniON</h1>  
    </div>
    <div class="nav">
        <input type="text" placeholder="What are you looking for?">
        <ul>
            <li><a href="companionprofile.php">Profile</a></li>                
            <li><a href="companionnotif.php">Notifications</a></li>
            <li><a href="verify.php">Verify</a></li>
            <li><a href="history.php">History</a></li>
        </ul>
    </div>
</header>

<section class="edit-profile">
    <h2>Edit Profile</h2>
    <form action="updateprofile.php" method="POST">
        <input type="hidden" name="profile_id" value="<?php echo $profile['ID']; ?>">

        <div class="form-group">
            <input type="text" name="first_name" placeholder="First Name" value="<?php echo htmlspecialchars($profile['Firstname']); ?>">
            <input type="text" name="last_name" placeholder="Last Name" value="<?php echo htmlspecialchars($profile['Lastname']); ?>">
        </div>

        <div class="form-group">
            <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($profile['Email']); ?>">
            <input type="text" name="phone" placeholder="Phone Number" value="<?php echo htmlspecialchars($profile['Contactnumber']); ?>">
        </div>

        <div class="form-group">
        <input type="date" name="date_of_birth" placeholder="Date of Birth" value="<?php echo htmlspecialchars($profile['date_of_birth'] ?? ''); ?>">
        <select name="gender">
                <option value="" disabled>Gender</option>
                <option value="Male" <?php echo ($profile['Gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo ($profile['Gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                <option value="Other" <?php echo ($profile['Gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
            </select>
            <input type="text" name="address" placeholder="Address" value="<?php echo htmlspecialchars($profile['Address']); ?>">
        </div>

        <div class="form-group bio">
            <textarea name="bio" placeholder="Bio" maxlength="255"><?php echo htmlspecialchars($profile['Bio']); ?></textarea>
            <textarea name="interests" placeholder="Interests & Hobbies" maxlength="255"><?php echo htmlspecialchars($profile['InterestsHobbies']); ?></textarea>
        </div>
        <div class="form-group action-buttons">
            <button type="submit" class="save">Update</button>
            <button type="button" class="exit" onclick="window.location.href='companionprofile.php';">Exit</button>
            </div>
    </form>
</section>
</div>
</body>
</html>
