<!--
Interest hobbies checkbox  -->

<?php
$host = 'localhost';
$dbname = 'companion1';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error connecting to the database: " . $e->getMessage());
}

// Fetch profile data by ID
$profile_id = isset($_GET['profile_id']) ? $_GET['profile_id'] : 1; 

$query = $pdo->prepare("SELECT * FROM users WHERE ID = :id");
$query->execute(['id' => $profile_id]);
$profile = $query->fetch(PDO::FETCH_ASSOC);
$dob = date("Y-m-d", strtotime($profile['date_of_birth']));

if (!$profile) {
    die("Profile not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Companion Profile</title>
    <link rel="stylesheet" href="editcompanionprofile.css">
</head>
<body>
<div class="container">
<header>
    <div class="logo">
        <h1>CompaniON</h1>  
    </div>
    <div class="nav">
        <input type="text" placeholder="What are you looking for?">
        <ul>
            <li><a href="companionprofile.php">Profile</a></li>                
            <li><a href="companionnotif.php">Notifications</a></li>
            <li><a href="verify.php">Verify</a></li>
            <li><a href="history.php">History</a></li>
        </ul>
    </div>
</header>

<section class="edit-profile">
    <h2>Edit Profile</h2>
    <form action="updateprofile.php" method="POST">
    <input type="hidden" name="profile_id" value="<?php echo $profile['ID']; ?>">

    <div class="form-group">
        <input type="text" name="first_name" placeholder="<?php echo htmlspecialchars($profile['Firstname']); ?>" value="">
        <input type="text" name="last_name" placeholder="<?php echo htmlspecialchars($profile['Lastname']); ?>" value="">
    </div>

    <div class="form-group">
        <input type="email" name="email" placeholder="<?php echo htmlspecialchars($profile['Email']); ?>" value="">
        <input type="tel" name="phone" placeholder="<?php echo htmlspecialchars($profile['Contactnumber']); ?>" value="" pattern="\d*" title="Only numeric values are allowed">
    </div>

    <div class="form-group">
    <input type="date" name="date_of_birth" value="<?php echo htmlspecialchars($dob); ?>">
    <select name="gender">
            <option value="" disabled>Gender</option>
            <option value="Male" <?php echo ($profile['Gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
            <option value="Female" <?php echo ($profile['Gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
            <option value="Other" <?php echo ($profile['Gender'] == 'Other') ? 'selected' : ''; ?>>Other</option>
        </select>
        <input type="text" name="address" placeholder="<?php echo htmlspecialchars($profile['Address']); ?>" value="">
    </div>

   
    <div class="form-group bio">
                <textarea name="bio" placeholder="Write a short bio..." maxlength="255"><?php echo htmlspecialchars($profile['Bio']); ?></textarea>
            </div>

            <div class="form-group">
                <label>Interests & Hobbies:</label>
                <div class="hobbies-container">
                    <?php 
                        $hobbies = ['Reading', 'Traveling', 'Cooking', 'Sports', 'Music', 'Photography', 'Dancing', 
                                    'Gaming', 'Drawing', 'Painting', 'Writing', 'Fishing', 'Hiking', 'Cycling', 
                                    'Camping', 'Swimming', 'Yoga', 'Fitness', 'Meditation', 'Programming', 
                                    'Technology', 'Shopping', 'Gardening', 'Birdwatching', 'Movies', 
                                    'TV Shows', 'Pets', 'Animals', 'Science', 'History',];
                        $selectedHobbies = !empty($profile['InterestsHobbies']) ? explode(', ', $profile['InterestsHobbies']) : [];
                    ?>
                    <?php foreach ($hobbies as $hobby): ?>
                        <label>
                            <input type="checkbox" name="interestshobbies[]" value="<?php echo $hobby; ?>" 
                            <?php echo in_array($hobby, $selectedHobbies) ? 'checked' : ''; ?>>
                            <?php echo $hobby; ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

    <div class="form-group action-buttons">
        <button type="submit" class="save">Update</button>
        <button type="button" class="exit" onclick="window.location.href='companionprofile.php';">Exit</button>
    </div>
</form>

</section>
</div>
</body>
</html>
