<?php
include '../connection.php';

$host = 'localhost';
$dbname = 'companion1';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error connecting to the database: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $profile_id = $_POST['profile_id'];
    
    // Fetch the existing profile data
    $query = $pdo->prepare("SELECT * FROM users WHERE ID = :profile_id");
    $query->execute(['profile_id' => $profile_id]);
    $profile = $query->fetch(PDO::FETCH_ASSOC);

    if (!$profile) {
        die("Profile not found.");
    }

    // Get new values or use existing if the form field is empty
    $first_name = !empty($_POST['first_name']) ? $_POST['first_name'] : $profile['Firstname'];
    $last_name = !empty($_POST['last_name']) ? $_POST['last_name'] : $profile['Lastname'];
    $email = !empty($_POST['email']) ? $_POST['email'] : $profile['Email'];
    $phone = !empty($_POST['phone']) ? $_POST['phone'] : $profile['Contactnumber'];
    $date_of_birth = !empty($_POST['date_of_birth']) ? $_POST['date_of_birth'] : $profile['Date_of_birth'];
    $gender = !empty($_POST['gender']) ? $_POST['gender'] : $profile['Gender'];
    $address = !empty($_POST['address']) ? $_POST['address'] : $profile['Address'];
    $bio = !empty($_POST['bio']) ? $_POST['bio'] : $profile['Bio'];
    $selectedHobbies = isset($_POST['interestshobbies']) ? implode(', ', $_POST['interestshobbies']) : $profile['InterestsHobbies'];

    // Prepare and execute the update query
    $updateQuery = $pdo->prepare("UPDATE users SET 
        Firstname = :first_name, 
        Lastname = :last_name, 
        Email = :email, 
        Contactnumber = :phone, 
        Date_of_birth = :date_of_birth, 
        Gender = :gender, 
        Address = :address, 
        Bio = :bio, 
        InterestsHobbies = :interestshobbies 
        WHERE ID = :profile_id");

    // Execute the query with new values or defaults
    $updateQuery->execute([
        'first_name' => $first_name,
        'last_name' => $last_name,
        'email' => $email,
        'phone' => $phone,
        'date_of_birth' => $date_of_birth,
        'gender' => $gender,
        'address' => $address,
        'bio' => $bio,
        'interestshobbies' => $selectedHobbies,
        'profile_id' => $profile_id
    ]);

    // Redirect after updating
    header("Location: companionprofile.php");
    exit();
}
?>
