<?php
$host = 'localhost';
$dbname = 'companion';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error connecting to the database: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input data
    $profile_id = $_POST['profile_id'] ?? null;
    $first_name = $_POST['first_name'] ?? null;
    $last_name = $_POST['last_name'] ?? null;
    $email = $_POST['email'] ?? null;
    $phone = $_POST['phone'] ?? null;
    $date_of_birth = $_POST['date_of_birth'] ?? null;
    $gender = $_POST['gender'] ?? null;
    $address = $_POST['address'] ?? null;
    $bio = $_POST['bio'] ?? null;
    $interests = $_POST['interests'] ?? null;

    // Ensure required fields
    if (!$first_name || !$email) {
        die("First name and email are required fields.");
    }

    // Update query
    $query = $pdo->prepare("
    UPDATE users 
    SET Firstname = :first_name, 
        Lastname = :last_name, 
        Email = :email, 
        Contactnumber = :phone, 
        Date_Of_Birth = :date_of_birth,  /* Match column name here */
        Gender = :gender, 
        Address = :address, 
        Bio = :bio, 
        InterestsHobbies = :interests 
    WHERE ID = :id
");

    // Execute the query
    try {
        $query->execute([
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'phone' => $phone,
            'date_of_birth' => $date_of_birth, // Make sure the variable is correct
            'gender' => $gender,
            'address' => $address,
            'bio' => $bio,
            'interests' => $interests,
            'id' => $profile_id,
        ]);

        header("Location: companionprofile.php?status=success");
        exit();
    } catch (PDOException $e) {
        die("Error updating profile: " . $e->getMessage());
    }
}
?>
