<?php
include '../connection.php';

$user_id = $_GET['user_id']; // Get user ID from the URL

// Fetch user details
$sql = "SELECT firstname, lastname, age, gender, address, bio FROM users WHERE id = ?";
$stmt = $data->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();
$data->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100">
    <header class="bg-white shadow-sm">
        <div class="container mx-auto px-4 py-4 flex justify-between items-center">
            <div class="text-2xl font-bold text-green-700">CompaniON</div>
            <div class="flex items-center space-x-4">
                <input type="text" placeholder="What are you looking for?" class="border rounded-full px-4 py-2 w-64">
                <nav class="space-x-4">
                    <a href="#" class="text-gray-700">Profile</a>
                    <a href="#" class="text-gray-700">Notifications</a>
                    <a href="#" class="text-gray-700">Verify</a>
                    <a href="#" class="text-gray-700">History</a>
                </nav>
            </div>
        </div>
    </header>
    <main class="container mx-auto px-4 py-8 flex space-x-8">
        <aside class="w-1/4">
            <div class="bg-white p-4 rounded-lg shadow-md mb-8">
                <h2 class="text-lg font-bold mb-4">Menu</h2>
                <div class="space-y-4">
                    <button class="w-full bg-green-100 text-green-700 py-2 rounded">Accept Booking</button>
                    <button class="w-full bg-gray-200 text-gray-700 py-2 rounded">Decline Booking</button>
                    <button class="w-full bg-gray-200 text-gray-700 py-2 rounded">Back</button>
                </div>
            </div>
            <div class="bg-white p-4 rounded-lg shadow-md">
                <h2 class="text-lg font-bold mb-4">Recommended Places</h2>
                <div class="space-y-4">
                    <div class="bg-gray-100 p-4 rounded-lg">
                        <div class="bg-gray-300 h-24 rounded mb-2"></div>
                        <p class="text-sm text-gray-600 mb-2">Short description about event. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <button class="bg-green-100 text-green-700 py-1 px-2 rounded text-sm">View Details</button>
                    </div>
                    <div class="bg-gray-100 p-4 rounded-lg">
                        <div class="bg-gray-300 h-24 rounded mb-2"></div>
                        <p class="text-sm text-gray-600 mb-2">Short description about event. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <button class="bg-green-100 text-green-700 py-1 px-2 rounded text-sm">View Details</button>
                    </div>
                </div>
            </div>
        </aside>
        <section class="w-3/4 bg-white p-8 rounded-lg shadow-md">
            <h2 class="text-lg font-bold mb-4">User’s Information</h2>
            <div class="flex space-x-8">
                <div class="w-1/4 bg-gray-100 h-48 rounded-lg"></div>
                <div class="w-3/4">
                    <h3 class="text-2xl font-bold text-green-700 mb-4">
                        <?php echo htmlspecialchars($user['firstname'] . ' ' . $user['lastname']); ?>
                    </h3>
                    <p><strong>Age:</strong> <?php echo htmlspecialchars($user['age']); ?></p>
                    <p><strong>Gender:</strong> <?php echo htmlspecialchars($user['gender']); ?></p>
                    <p><strong>Address:</strong> <?php echo htmlspecialchars($user['address']); ?></p>
                    <p><strong>Bio:</strong> <?php echo htmlspecialchars($user['bio']); ?></p>
                </div>
            </div>
        </section>
    </main>
</body>
</html>
