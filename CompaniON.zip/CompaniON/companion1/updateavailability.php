<?php
session_start();
include("../connection.php");

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../loginform.php");
    exit();
}

// Get the user ID from session
$user_id = $_SESSION['user_id'];

// Check if the availability value was sent via POST
if (isset($_POST['availability'])) {
    $availability = mysqli_real_escape_string($data, $_POST['availability']); // Sanitize the input

    // Update the user's availability in the database
    $query = "UPDATE users SET availability = '$availability' WHERE id = '$user_id'";

    if (mysqli_query($data, $query)) {
        // Redirect back to profile page after updating
        header("Location: companionprofile.php");
    } else {
        // Show an error if the update failed
        echo "Error updating availability: " . mysqli_error($data);
    }
} else {
    echo "No availability data received.";
}
?>
