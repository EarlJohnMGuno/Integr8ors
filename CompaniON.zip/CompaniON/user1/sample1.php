
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CompaniON Profile</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap"
      rel="stylesheet"
    />
    <style>
        body {
    background-color: #f8f8f8;
    color: #333;
  }

  .container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 10px;
  }
  header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 60px; /* Fixed height for the navbar */
    padding: 0 20px; /* Horizontal padding */
    background-color: #e8f1e1;
    border-bottom: 1px solid #ddd;
    margin: 0;
  }

  /* Logo */
  header .logo {
    max-width: 150px;
    height: auto;
  }

  header .logo img {
    max-width: 100%;
    height: auto;
  }

  /* Navigation Bar */
  header .nav {
    display: flex;
    align-items: center;
    flex-grow: 1;
    justify-content: space-between;
    margin-left: 20px; /* Increased space between logo and nav */
  }

  /* Search Bar */
  header .search-bar {
    flex-grow: 1;
    display: flex;
    justify-content: center;
    margin-right: 20px; /* Increased spacing on the right side of the search bar */
  }

  header .search-bar input {
    width: 50%;
    padding: 6px;
    border-width: 1px;
    border-style: solid;
    border-color: rgb(221, 221, 221);
    border-radius: 4px;
    transition: width 0.3s ease-in-out;
  }

  /* Navigation Links */
  header .nav ul {
    list-style-type: none;
    display: flex;
    gap: 20px; /* Increased gap between navigation links */
    margin: 0;
  }

  header .nav ul li {
    transition: transform 0.3s ease-in-out;
  }

  header .nav ul li a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
    transition: color 0.3s ease, transform 0.3s ease;
  }

  header .nav ul li a:hover {
    color: #718659;
    transform: scale(1.1);
  }

  /* Responsive Behavior */
  @media (max-width: 768px) {
    header {
      flex-direction: column;
      height: auto; /* Auto height for smaller screens */
      padding: 10px; /* Padding adjustment for smaller screens */
    }

    header .nav {
      flex-direction: column;
      align-items: center;
      margin-left: 0;
    }

    header .search-bar input {
      width: 80%;
    }

    header .nav ul {
      flex-direction: column;
      gap: 15px; /* Reduced gap for smaller screens */
    }
  }

  /* Modal Styles */
  .modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    align-items: center;
    justify-content: center;
    z-index: 50;
  }

  .modal.active {
    display: flex;
  }
    </style>

  </head>

  <body class="bg-gray-100">
    <header>
      <div class="logo">
        <img src="Assets/logo.png" alt="CompaniON Logo" />
      </div>

      <div class="nav">
        <div class="search-bar">
          <input placeholder="What are you looking for?" type="text" />
        </div>
        <ul>
          <li><a href="index.html">Home </a></li>
          <li><a href="rentcompanion.php">Companion </a></li>
          <li><a href="howitworks.html">How it works </a></li>
          <li><a href="generaluserprofile.html">Profile</a></li>
        </ul>
      </div>
    </header>
</body>
</html>