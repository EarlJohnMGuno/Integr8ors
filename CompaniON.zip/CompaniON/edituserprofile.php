<html>
<head>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }
        .input-shadow {
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-3xl">
        <h1 class="text-2xl font-medium text-green-700 mb-6">Edit Profile</h1>
        <form action="update-profile.php" method="POST">
`        <div class="grid grid-cols-2 gap-6 mb-6">
            <div>
                <label class="block text-gray-700 mb-2">First Name</label>
                <input type="text" name="firstName" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 input-shadow">
            </div>
            <div>
                <label class="block text-gray-700 mb-2">Last Name</label>
                <input type="text" name="lastName" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 input-shadow">
            </div>
            <div>
                <label class="block text-gray-700 mb-2">Email</label>
                <input type="email" name="email" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 input-shadow">
            </div>
            <div>
                <label class="block text-gray-700 mb-2">Contact Number</label>
                <input type="text" name="contactNumber" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 input-shadow">
            </div>
            <div>
                <label class="block text-gray-700 mb-2">Date of Birth</label>
                <input type="date" name="dob" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 input-shadow">
            </div>
            <div>
                <label class="block text-gray-700 mb-2">Gender</label>
                <select name="gender" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 input-shadow">
                    <option value="" disabled selected>Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
            </div>
            <div>
                <label class="block text-gray-700 mb-2">Address</label>
                <input type="text" name="address" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 input-shadow">
            </div>
        </div>
        <div class="mb-6">
            <label class="block text-gray-700 mb-2">Bio</label>
            <textarea name="bio" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 input-shadow" rows="4"></textarea>
        </div>

        <div class="flex justify-end space-x-4">
            <button type="submit" class="bg-green-500 text-white py-2 px-6 rounded-lg">Save</button>
            <button type="button" class="bg-red-500 text-white py-2 px-6 rounded-lg" onclick="window.location.href='index.html'">Exit</button>
        </div>
    </form>
    </div>
</body>
</html>