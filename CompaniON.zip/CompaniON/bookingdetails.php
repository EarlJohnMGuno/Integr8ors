<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
    <link rel="stylesheet" href="bookings.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="Assets/logo.png" alt="CompaniON Logo">
        </div>
        <div class="nav">
            <div class="search-bar">
                <input placeholder="What are you looking for?" type="text">
            </div>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="rentcompanion.php">Companion</a></li>
                <li><a href="howitworks.html">How it works</a></li>
                <li><a href="">Profile</a></li>
            </ul>
        </div>
    </header>
    <div class="content">
        <div class="container">
            <div class="header">
                <h1>BOOK</h1>
                <div class="lines">Short description here that fill out all</div>
            </div>
            
            <!-- Begin form, set action to submitbooking.php and method to POST -->
            <form id="bookingForm" action="submitbooking.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>Preferred Date</label>
                        <input type="text" id="preferred-date" name="preferred_date">
                    </div>
                    <div class="form-group">
                        <label>Preferred Time</label>
                        <input type="text" id="preferred-time" name="preferred_time">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Duration (hours)</label>
                        <input type="number" name="duration" min="1" max="24" step="1">
                    </div>
                    <div class="form-group">
                        <label>Location/Place</label>
                        <select id="location-place" name="location_place">
                            <option value="The Outlets">The Outlets</option>
                            <option value="SM City Lipa">SM City Lipa</option>
                            <option value="Robinsons Lipa">Robinsons Lipa</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Event Type</label>
                    <select name="event_type">
                        <option value="CICS Day at BatStateU Lipa">CICS Day at BatStateU Lipa</option>
                        <option value="Barako Festival">Barako Festival</option>
                        <option value="Milo Marathon">Milo Marathon</option>
                        <option value="None">None</option>
                    </select>
                </div>
                
                <div class="form-group special-requests">
                    <label>Special Requests:</label>
                    <textarea name="special_requests" maxlength="255"></textarea>
                    <span>0/255</span>
                </div>
                
                <!-- Submit button -->
                <button type="button" id="confirmBookingBtn" class="confirm-btn">Confirm</button>
                <button type="button" class="cancel-btn" onclick="window.location.href='companiondetails.php';">Cancel</button>
            </form>
            
            <div class="terms">
                <hr>
                <label>
                    <input type="checkbox" id="termsCheckbox"> I have read and agree to the 
                    <a href="#" onclick="openModal('termsModal')">Terms and Conditions</a> and 
                    <a href="#" onclick="openModal('privacyModal')">Privacy Policy</a>.
                </label>
            </div>
        </div>
    </div>

    <!-- Modal for Confirm Booking -->
    <div id="confirmBookingModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Do you want to confirm your booking?</h2>
            </div>
            <div class="modal-footer">
                <button id="confirmYes" class="confirm-btn">Yes</button>
                <button id="confirmNo" class="cancel-btn">No</button>
            </div>
        </div>
    </div>

    <!-- Modal for Booking Submitted -->
    <div id="bookingSubmittedModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Booking Submitted Successfully!</h2>
            </div>
            <div class="modal-footer">
                <button id="goToProfile" class="confirm-btn">Go to Profile</button>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
    <script>
        $(function() {
            $("#preferred-date").datepicker({
                minDate: 0 // Restrict past dates
            });
            $("#preferred-time").timepicker({
                timeFormat: 'h:mm p',
                interval: 30,
                minTime: '6:00am',
                maxTime: '11:00pm',
                defaultTime: '6:00am',
                startTime: '6:00am',
                dynamic: false,
                dropdown: true,
                scrollbar: true
            });
        });

        // Open confirm booking modal on clicking confirm button
        $("#confirmBookingBtn").on("click", function() {
            if ($("#termsCheckbox").is(":checked")) {
                $("#confirmBookingModal").show();
            } else {
                alert("Please agree to the Terms and Conditions before booking.");
            }
        });

        // Confirm booking modal actions
        $("#confirmYes").on("click", function() {
            $("#confirmBookingModal").hide();
            $("#bookingForm").submit();
        });
        $("#confirmNo").on("click", function() {
            $("#confirmBookingModal").hide();
        });

        // Booking Submitted modal actions
        $("#goToProfile").on("click", function() {
            window.location.href = "generaluserprofile.html";
        });
    </script>
</body>
</html>
