<?php
    include ("connection.php");
    include ("home.php")
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompaniON</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Your custom styles (styles.css) -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title text-center">Log in</h2>
                        <hr>
                        <form name="form" action="login.php" method="POST">
                            <div class="form-group">
                                <input type="text" name="email" id="email" placeholder="Enter your Email" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" id="password" placeholder="Enter your Password" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Log in</button>
                        </form>
                        <p class="mt-3 text-center">Don't have an account? <a href="registerform.php">Register Here</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS (optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
