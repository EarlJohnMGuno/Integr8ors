<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="loginform.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>CompaniON</h1>
        </div>
        <div class="nav">
            <input type="text" placeholder="What are you looking for?">
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Companion</a></li>
                <li><a href="#">How it work</a></li>
            </ul>
            <button class="login-btn">Login</button>
        </div>
    </header>

    <div class="login-container">
        <div class="login-box">
            <h2>Login</h2>
            <form action="login.php" method="POST">
                <label for="email">Username:</label>
                <input type="email" id="email" name="email" required>
                
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                
                <button type="submit" class="login-button">LOGIN</button>
                <p>Don't have an account? <a href="choosereg.php">Register here</a></p>
            </form>



            </form>
        </div>
    </div>
</body>
</html>
