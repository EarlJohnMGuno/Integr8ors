<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Account - CompaniON</title>
    <link rel="stylesheet" href="registerform.css"> <!-- Link to your external CSS -->
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>CompaniON</h1>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="What are you looking for?">
            </div>
            <nav>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Companion</a></li>
                    <li><a href="#">How it works</a></li>
                    <li><a href="#" class="login-btn">Login</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="register-container">
        <form action="userregistration.php" method="POST" class="register-form">
            <h2>Register Account</h2>
            <div class="form-row">
                <input type="text" name="firstname" placeholder="First Name" required>
                <input type="text" name="lastname" placeholder="Last Name" required>
            </div>
        
            <div class="form-row">
            <input type="date" name="date_of_birth" placeholder="Date of Birth" required id="date_of_birth">
            <select name="gender" required>
                    <option value="" disabled selected>Gender:</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <input type="email" name="email" placeholder="Email" required>            
            <input type="text" name="contactnumber" placeholder="Contact Number" required>
            <input type="text" name="address" placeholder="Address" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>

            <button type="submit">Register</button>
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </form>
    </div>

    <script>
        const dateOfBirthInput = document.getElementById('date_of_birth');
        const today = new Date();
        today.setFullYear(today.getFullYear() - 18);
        dateOfBirthInput.max = today.toISOString().split("T")[0];
    </script>

</body>
</html>
