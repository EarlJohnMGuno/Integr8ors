<html>
<head>
    <title>CompanION</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            text-align: center;
            background-color: white;
            padding: 50px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            width: 100%;
            padding: 10px 0;
            background-color: white;
            border-bottom: 1px solid #ddd;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .header .logo {
            font-size: 24px;
            color: #6aa84f;
            font-weight: bold;
        }
        .header .search-bar {
            flex-grow: 1;
            margin: 0 20px;
        }
        .header .search-bar input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .header .nav-links {
            display: flex;
            gap: 20px;
        }
        .header .nav-links a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
        }
        .header .login-button {
            background-color: #6aa84f;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
        }
        .container h1 {
            color: #6aa84f;
            font-size: 36px;
            margin-bottom: 20px;
        }
        .container .lines {
            margin: 20px 0;
        }
        .container .lines div {
            height: 2px;
            background-color: #ddd;
            margin: 5px 0;
        }
        .container .buttons {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .container .buttons button {
            padding: 15px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
        }
        .container .buttons .find-companion {
            background-color: #d9ead3;
            color: #6aa84f;
        }
        .container .buttons .be-companion {
            background-color: #f2f2f2;
            color: #333;
        }

        .container .buttons a {
            padding: 15px;
            border-radius: 5px;
            font-size: 18px;
            display: inline-block;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
            width: 100%;
        }
        .container .buttons .find-companion {
            background-color: #d9ead3;
            color: #6aa84f;
        }
        .container .buttons .be-companion {
            background-color: #f2f2f2;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">CompanION</div>
        <div class="search-bar">
            <input type="text" placeholder="What are you looking for?">
        </div>
        <div class="nav-links">
            <a href="#">Home</a>
            <a href="#">Companion</a>
            <a href="#">How it work</a>
        </div>
        <a href="loginform.php" class="login-button">Login</a>
    </div>
    <div class="container">
        <h1>Welcome</h1>
        <div class="lines">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        <div class="buttons">
            <a href="userregisterform.php" class="find-companion">Find a Companion</a>
            <a href="registerform.php" class="be-companion">Be a Companion</a>
        </div>
    </div>
</body>
</html>