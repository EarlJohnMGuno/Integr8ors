
<?php
$servername = "localhost";  // Change this if needed
$username = "root";  // Database username
$password = "";  // Database password
$dbname = "RGO";  // Name of your database

// Create a connection
$data = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$data) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
