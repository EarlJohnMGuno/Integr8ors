-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2024 at 11:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `companion1`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `companion_id` int(11) NOT NULL,
  `preferred_date` date NOT NULL,
  `preferred_time` time NOT NULL,
  `duration` int(11) NOT NULL,
  `location_place` varchar(255) DEFAULT NULL,
  `event_type` varchar(100) DEFAULT NULL,
  `special_requests` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `user_id`, `companion_id`, `preferred_date`, `preferred_time`, `duration`, `location_place`, `event_type`, `special_requests`, `created_at`) VALUES
(3, 1, 1, '2024-11-05', '06:00:00', 2, 'The Outlets', 'CICS Day at BatStateU Lipa', 'sffsfs', '2024-11-03 19:55:18'),
(4, 2, 2, '2024-11-18', '06:00:00', 2, 'The Outlets', 'CICS Day at BatStateU Lipa', 'hahahaha', '2024-11-03 19:56:56');

-- --------------------------------------------------------

--
-- Table structure for table `companion_table`
--

CREATE TABLE `companion_table` (
  `companion_id` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `Firstname` varchar(55) NOT NULL,
  `Lastname` varchar(55) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(55) NOT NULL,
  `Contactnumber` varchar(55) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Availability` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Usertype` varchar(55) NOT NULL DEFAULT 'User',
  `Status` varchar(55) NOT NULL DEFAULT 'Not Verified',
  `ID_pic` longblob NOT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `Bio` varchar(255) DEFAULT NULL,
  `InterestsHobbies` varchar(255) DEFAULT NULL,
  `id_front` varchar(255) DEFAULT NULL,
  `id_back` varchar(255) DEFAULT NULL,
  `selfie_front` varchar(255) DEFAULT NULL,
  `selfie_back` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `companion_table`
--

INSERT INTO `companion_table` (`companion_id`, `ID`, `Firstname`, `Lastname`, `Age`, `Gender`, `Contactnumber`, `Email`, `Address`, `Availability`, `Password`, `Usertype`, `Status`, `ID_pic`, `DateOfBirth`, `Bio`, `InterestsHobbies`, `id_front`, `id_back`, `selfie_front`, `selfie_back`) VALUES
(1, 1, 'Earl John', 'Guno', 0, '', '', 'gunoearljohn@gmail.com', '', '', '', 'Companion', 'Not Verified', '', NULL, 'nya', 'Reading, Traveling, Cooking, Sports, Gaming', NULL, NULL, NULL, NULL),
(2, 2, 'Kylla Mae', 'Paragas', 0, '', '', 'kylla@gmail.com', '', '', '', 'Companion', 'Not Verified', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 3, 'Glycel', 'Virtucio', 0, '', '', 'glycel@gmail.com', '', '', '', 'Companion', 'Not Verified', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `Firstname` varchar(55) NOT NULL,
  `Lastname` varchar(55) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(55) NOT NULL,
  `Contactnumber` varchar(55) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Availability` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Usertype` varchar(55) NOT NULL DEFAULT 'User',
  `Status` varchar(55) NOT NULL DEFAULT 'Not Verified',
  `Bio` varchar(255) DEFAULT NULL,
  `InterestsHobbies` varchar(255) DEFAULT NULL,
  `id_front` longblob DEFAULT NULL,
  `id_back` longblob DEFAULT NULL,
  `selfie_front` longblob DEFAULT NULL,
  `selfie_back` longblob DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `Firstname`, `Lastname`, `Age`, `Gender`, `Contactnumber`, `Email`, `Address`, `Availability`, `Password`, `Usertype`, `Status`, `Bio`, `InterestsHobbies`, `id_front`, `id_back`, `selfie_front`, `selfie_back`, `date_of_birth`) VALUES
(1, 'Earl John', 'Guno', 20, 'Male', '09395718274', 'gunoearljohn@gmail.com', 'Lipa City Batangas', 'Monday', '$2y$10$IP80cpa1m6LBQ6su8Q4F/OBprboH0/OeCjo9njeVikJDTR6ivT2Cu', 'Companion', ' Verified', 'nya', 'Reading, Traveling, Cooking, Sports, Gaming', NULL, NULL, NULL, NULL, '2004-08-05'),
(2, 'Kylla Mae', 'Paragas', 20, 'Female', '09111111111', 'kylla@gmail.com', 'Lipa Batangas', 'Tuesday', '$2y$10$f68M8qTzm/HRwFTh14ruWeEijkzG7lqseadqYTEHNsQY83./z5WUC', 'Companion', ' Verified', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Glycel', 'Virtucio', 20, 'Female', '09111111111', 'glycel@gmail.com', 'Lipa Batangas', 'Wednesday', '$2y$10$MU7Rk7ptKTITC09xQTgNI.S5B/BKIaV2d9h0tbwi2VM6NgD3BXCdC', 'Companion', ' Verified', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Marco', 'Guno', 19, 'Male', '09111111111', 'marco@gmail.com', 'Lipa Batangas', '', '$2y$10$i/hGzo3mxXlmOqEp59aI6OoxvmRD/.DtlfVMgRR0NQhIpQp69c66K', 'User', 'Verified', NULL, NULL, NULL, NULL, NULL, NULL, '2005-09-12'),
(5, 'Anjella', 'Guno', 19, 'Male', '09111111111', 'anjella@gmail.com', 'Lipa Batangas', '', '$2y$10$sW1te287VxzBH8DMd0gQSuGYLyif2O2CwTuWh63WyOs99e/FfSxEe', 'User', 'Not Verified', NULL, NULL, NULL, NULL, NULL, NULL, '2005-09-12'),
(6, 'Regulus', 'Corneas', 18, 'Male', '09111111111', 'Regulus@gmail.com', 'Lipa Batangas', '', '$2y$10$XYNZ8s8SOddQs/l8nFFRX.jCUu6yKXbOjU/rfurynAfB2XIlhK/lW', 'User', 'Not Verified', NULL, NULL, NULL, NULL, NULL, NULL, '2006-11-01');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `after_user_insert` AFTER INSERT ON `users` FOR EACH ROW BEGIN
    IF NEW.Usertype = 'Companion' THEN
        INSERT INTO companion_table (ID, Firstname, Lastname, Bio, Email, InterestsHobbies)
        VALUES (NEW.ID, NEW.Firstname, NEW.Lastname, NEW.Bio, NEW.Email, NEW.InterestsHobbies);
    ELSE
        INSERT INTO users_table (ID, Firstname, Lastname, Bio, Email, InterestsHobbies)
        VALUES (NEW.ID, NEW.Firstname, NEW.Lastname, NEW.Bio, NEW.Email, NEW.InterestsHobbies);
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_user_update` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
    IF NEW.Usertype = 'Companion' THEN
        INSERT INTO companion_table (ID, Firstname, Lastname, Bio, Email, InterestsHobbies)
        VALUES (NEW.ID, NEW.Firstname, NEW.Lastname, NEW.Bio, NEW.Email, NEW.InterestsHobbies)
        ON DUPLICATE KEY UPDATE
            Firstname = NEW.Firstname,
            Lastname = NEW.Lastname,
            Bio = NEW.Bio,
            Email = NEW.Email,
            InterestsHobbies = NEW.InterestsHobbies;
    ELSE
        DELETE FROM companion_table WHERE ID = NEW.ID;
        INSERT INTO users_table (ID, Firstname, Lastname, Bio, Email, InterestsHobbies)
        VALUES (NEW.ID, NEW.Firstname, NEW.Lastname, NEW.Bio, NEW.Email, NEW.InterestsHobbies)
        ON DUPLICATE KEY UPDATE
            Firstname = NEW.Firstname,
            Lastname = NEW.Lastname,
            Bio = NEW.Bio,
            Email = NEW.Email,
            InterestsHobbies = NEW.InterestsHobbies;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users_table`
--

CREATE TABLE `users_table` (
  `user_id` int(11) NOT NULL,
  `Firstname` varchar(55) NOT NULL,
  `Lastname` varchar(55) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(55) NOT NULL,
  `Contactnumber` varchar(55) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Availability` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Usertype` varchar(55) NOT NULL DEFAULT 'User',
  `Status` varchar(55) NOT NULL DEFAULT 'Not Verified',
  `ID` int(11) NOT NULL,
  `Bio` varchar(255) DEFAULT NULL,
  `InterestsHobbies` varchar(255) DEFAULT NULL,
  `id_front` varchar(255) DEFAULT NULL,
  `id_back` varchar(255) DEFAULT NULL,
  `selfie_front` varchar(255) DEFAULT NULL,
  `selfie_back` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_table`
--

INSERT INTO `users_table` (`user_id`, `Firstname`, `Lastname`, `Age`, `Gender`, `Contactnumber`, `Email`, `Address`, `Availability`, `Password`, `Usertype`, `Status`, `ID`, `Bio`, `InterestsHobbies`, `id_front`, `id_back`, `selfie_front`, `selfie_back`) VALUES
(1, 'Marco', 'Guno', 0, '', '', 'marco@gmail.com', '', '', '', 'User', 'Not Verified', 4, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Anjella', 'Guno', 0, '', '', 'anjella@gmail.com', '', '', '', 'User', 'Not Verified', 5, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Regulus', 'Corneas', 0, '', '', 'Regulus@gmail.com', '', '', '', 'User', 'Not Verified', 6, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `companion_id` (`companion_id`);

--
-- Indexes for table `companion_table`
--
ALTER TABLE `companion_table`
  ADD PRIMARY KEY (`companion_id`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users_table`
--
ALTER TABLE `users_table`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `companion_table`
--
ALTER TABLE `companion_table`
  MODIFY `companion_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users_table`
--
ALTER TABLE `users_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_companion` FOREIGN KEY (`companion_id`) REFERENCES `companion_table` (`companion_id`),
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`ID`);

--
-- Constraints for table `companion_table`
--
ALTER TABLE `companion_table`
  ADD CONSTRAINT `companion_fk_user` FOREIGN KEY (`ID`) REFERENCES `users` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `users_table`
--
ALTER TABLE `users_table`
  ADD CONSTRAINT `user_fk_user` FOREIGN KEY (`ID`) REFERENCES `users` (`ID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
